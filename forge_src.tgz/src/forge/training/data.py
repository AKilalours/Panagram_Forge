"""Training data: Parquet in, padded windowed batches out.

Kept deliberately separate from the fit loop so the parts that can be tested without
torch stay testable. `build_examples` is pure given a tokenizer, and there is a fake
tokenizer in the tests that exercises the whole path on CPU with no downloads.

Two things this file is careful about:

**The group id travels with every example.** Splits were already assigned at ingestion
and mirrors inherited them, so nothing here re-splits. But carrying `source_group_id`
through to the batch means a leak check can be run on the actual training data rather
than trusted from two stages earlier.

**Human and AI documents are windowed identically.** If AI documents were truncated and
human ones windowed, or vice versa, the model would learn the artefact of the difference
rather than authorship.
"""

from __future__ import annotations

import glob
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import pyarrow.parquet as pq

from forge.common.schemas import Label, Split, TokenLabel
from forge.modeling.alignment import IGNORE_INDEX, align_spans_to_tokens
from forge.modeling.windowing import windows


@dataclass
class TrainExample:
    input_ids: list[int]
    attention_mask: list[int]
    doc_label: int
    token_labels: list[int]
    doc_id: str
    source_group_id: str
    split: str


def load_documents(
    human_root: str | Path | None = None,
    mirror_root: str | Path | None = None,
    splits: tuple[str, ...] = ("train",),
    limit: int | None = None,
) -> list[dict]:
    """Return [{doc_id, source_group_id, text, label, split}] from the data lake."""
    out: list[dict] = []

    if human_root:
        from forge.ingestion.writer import PARTITION_GLOB

        for f in sorted(glob.glob(str(Path(human_root) / PARTITION_GLOB))):
            t = pq.read_table(f, columns=["doc_id", "source_group_id", "text", "split"])
            for r in t.to_pylist():
                if r["split"] in splits:
                    out.append({**r, "label": 0})
                    if limit and len(out) >= limit:
                        break

    if mirror_root:
        for f in sorted(glob.glob(str(Path(mirror_root) / "split=*/*.parquet"))):
            t = pq.read_table(f, columns=["sample_id", "source_group_id", "text", "split"])
            for r in t.to_pylist():
                if r["split"] in splits:
                    out.append({
                        "doc_id": r["sample_id"], "source_group_id": r["source_group_id"],
                        "text": r["text"], "split": r["split"], "label": 1,
                    })
    return out


def build_examples(
    docs: Iterable[dict],
    tokenizer: Any,
    max_length: int = 512,
    stride: int = 384,
    max_windows_per_doc: int | None = 4,
) -> list[TrainExample]:
    """Tokenise, window, and attach document and token labels.

    `max_windows_per_doc` caps how many windows one long document contributes. Without a
    cap, a handful of very long documents dominate a batch and the effective sampling
    distribution stops matching the document distribution.
    """
    out: list[TrainExample] = []
    for d in docs:
        enc = tokenizer(
            d["text"],
            return_offsets_mapping=True,
            add_special_tokens=True,
            truncation=False,
        )
        ids = enc["input_ids"]
        offsets = [tuple(o) for o in enc["offset_mapping"]]
        if len(ids) < 8:
            continue

        label = Label.HUMAN if d["label"] == 0 else Label.AI
        tl = TokenLabel.HUMAN if label is Label.HUMAN else TokenLabel.AI_GENERATED
        spans = [(0, max(len(d["text"]), 1), tl)]
        token_labels = align_spans_to_tokens(offsets, spans)

        wins = windows(len(ids), size=max_length, stride=stride)
        if max_windows_per_doc:
            wins = wins[:max_windows_per_doc]
        for a, b in wins:
            out.append(
                TrainExample(
                    input_ids=ids[a:b],
                    attention_mask=[1] * (b - a),
                    doc_label=d["label"],
                    token_labels=token_labels[a:b],
                    doc_id=d["doc_id"],
                    source_group_id=d["source_group_id"],
                    split=d["split"],
                )
            )
    return out


def collate(batch: list[TrainExample], pad_id: int = 0):  # pragma: no cover - needs torch
    """Pad to the longest sequence in the batch. Padding positions get IGNORE_INDEX so
    the token loss never trains on them."""
    import torch

    n = max(len(e.input_ids) for e in batch)
    return {
        "input_ids": torch.tensor([e.input_ids + [pad_id] * (n - len(e.input_ids)) for e in batch]),
        "attention_mask": torch.tensor([e.attention_mask + [0] * (n - len(e.attention_mask)) for e in batch]),
        "doc_labels": torch.tensor([e.doc_label for e in batch]),
        "token_labels": torch.tensor(
            [e.token_labels + [IGNORE_INDEX] * (n - len(e.token_labels)) for e in batch]
        ),
        "doc_ids": [e.doc_id for e in batch],
        "group_ids": [e.source_group_id for e in batch],
    }


class WindowDataset:  # pragma: no cover - needs torch
    def __init__(self, examples: list[TrainExample]) -> None:
        self.examples = examples

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, i: int) -> TrainExample:
        return self.examples[i]


def assert_no_leakage(train: list[TrainExample], val: list[TrainExample]) -> None:
    """Re-check the invariant on the ACTUAL training data.

    Splits were assigned at ingestion and inherited by mirrors, three stages upstream. A
    check here costs nothing and catches a bad join, a mislabelled directory, or a config
    pointing at the wrong mirror root.
    """
    overlap = {e.source_group_id for e in train} & {e.source_group_id for e in val}
    if overlap:
        raise RuntimeError(
            f"{len(overlap)} source groups appear in both train and val, e.g. "
            f"{sorted(overlap)[:3]}. Every metric from this run would be inflated."
        )
