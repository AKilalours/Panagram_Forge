"""Phase 3 training entrypoint. The fit loop.

Decisions in here that change results, stated so they are visible rather than emergent:

**Best model is selected on FPR at the budget, not on validation loss.** A run whose loss
improved while its FPR-at-budget got worse has not improved for this product. Selecting on
loss is the default everywhere and it is the wrong default here.

**The threshold is refitted on validation every epoch.** The operating point moves as the
model changes, so an FPR computed against a stale threshold describes a model that no
longer exists.

**Checkpoint resume restores everything**: model, optimizer, scheduler, scaler, epoch and
step. Spot instances are the affordable way to run this, and a run that cannot resume
turns every preemption into a lost day.

**Leakage is re-checked on the actual batched data**, not trusted from ingestion three
stages upstream.

torch and transformers are imported lazily so the rest of the package still works without
them. Run `forge train --smoke` first: it exercises this entire path on CPU with a tiny
synthetic corpus in about a minute, and it is the cheapest possible way to find a bug
before renting a GPU.
"""

from __future__ import annotations

import json
import math
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np

from forge.common.config import REPO_ROOT, load
from forge.evaluation import metrics as M
from forge.evaluation.calibration import apply_temperature, fit_temperature
from forge.training.data import (
    TrainExample,
    assert_no_leakage,
    build_examples,
    collate,
    load_documents,
)


@dataclass
class TrainState:
    epoch: int = 0
    global_step: int = 0
    best_fpr: float = float("inf")
    best_epoch: int = -1
    dataset_version: str = ""
    code_commit: str = ""
    history: list[dict] = field(default_factory=list)


def _code_commit() -> str:
    import subprocess

    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL, text=True
        ).strip()
    except Exception:
        return "unknown"


def save_checkpoint(path, model, optimizer, scheduler, scaler, state: TrainState) -> None:
    import torch

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict() if optimizer else None,
            "scheduler": scheduler.state_dict() if scheduler else None,
            "scaler": scaler.state_dict() if scaler else None,
            "state": asdict(state),
        },
        path,
    )
    Path(str(path) + ".json").write_text(json.dumps(asdict(state), indent=2) + "\n")


def load_checkpoint(path, model, optimizer=None, scheduler=None, scaler=None) -> TrainState:
    import torch

    ck = torch.load(path, map_location="cpu", weights_only=False)
    model.load_state_dict(ck["model"])
    if optimizer and ck.get("optimizer"):
        optimizer.load_state_dict(ck["optimizer"])
    if scheduler and ck.get("scheduler"):
        scheduler.load_state_dict(ck["scheduler"])
    if scaler and ck.get("scaler"):
        scaler.load_state_dict(ck["scaler"])
    return TrainState(**ck["state"])


# ---------------------------------------------------------------- evaluation

def _aggregate_by_document(doc_ids, scores, labels):
    """Windows belong to documents. The metric is per DOCUMENT, so windows are averaged.

    Scoring per window would weight long documents more heavily than short ones, and the
    production decision is made per document.
    """
    agg: dict[str, list[float]] = {}
    lab: dict[str, int] = {}
    for d, s, y in zip(doc_ids, scores, labels):
        agg.setdefault(d, []).append(float(s))
        lab[d] = int(y)
    keys = sorted(agg)
    return ([lab[k] for k in keys], [float(np.mean(agg[k])) for k in keys])


def evaluate(model, loader, device, fpr_budget: float) -> dict:
    import torch

    model.eval()
    all_scores, all_labels, all_docs, all_logits = [], [], [], []
    with torch.no_grad():
        for batch in loader:
            out = model(
                input_ids=batch["input_ids"].to(device),
                attention_mask=batch["attention_mask"].to(device),
            )
            logits = out["doc_logits"].float().cpu()
            probs = torch.softmax(logits, dim=-1)[:, 1]
            all_logits.append(logits.numpy())
            all_scores.extend(probs.tolist())
            all_labels.extend(batch["doc_labels"].tolist())
            all_docs.extend(batch["doc_ids"])

    y, s = _aggregate_by_document(all_docs, all_scores, all_labels)
    y_arr = np.asarray(y)
    if (y_arr == 0).sum() == 0 or (y_arr == 1).sum() == 0:
        raise RuntimeError("validation set is missing one of the two classes")

    thr = M.threshold_at_fpr(y, s, fpr_budget)

    # Calibrate at the DOCUMENT level, not the window level.
    #
    # Found in the first smoke run: fitting a temperature on window logits and then
    # reporting document-level ECE moved ECE from 0.4544 to 0.4558, i.e. calibration did
    # nothing and slightly hurt. The reason is that the product decision and the reported
    # metric are both per document, and averaging window probabilities changes the score
    # distribution, so a temperature fitted on windows does not calibrate the thing that
    # is actually reported. It looks like calibration is in place while achieving nothing.
    doc_scores = np.clip(np.asarray(s, dtype=float), 1e-6, 1 - 1e-6)
    doc_logits = np.stack([np.zeros_like(doc_scores), np.log(doc_scores / (1 - doc_scores))], axis=1)
    temperature, t_at_bound = fit_temperature(doc_logits, np.asarray(y), return_boundary_flag=True)
    s_cal = apply_temperature(doc_logits, temperature)[:, 1].tolist()
    y_cal = y

    return {
        "threshold": float(thr),
        "fpr": M.false_positive_rate(y, s, thr),
        "fnr": M.false_negative_rate(y, s, thr),
        "auroc": M.auroc(y, s),
        "ece": M.expected_calibration_error(y, s),
        "ece_calibrated": M.expected_calibration_error(y_cal, s_cal),
        "temperature": float(temperature),
        "temperature_at_search_boundary": bool(t_at_bound),
        "n_documents": len(y),
        "n_human": int((y_arr == 0).sum()),
        "n_ai": int((y_arr == 1).sum()),
        "fpr_measurable": bool((y_arr == 0).sum() >= math.ceil(5 / max(fpr_budget, 1e-9))),
    }


# ---------------------------------------------------------------- fit loop

def run(config_path: str, smoke: bool = False, resume: str | None = None) -> dict:
    import torch
    from torch.utils.data import DataLoader
    if not smoke:
        from transformers import AutoTokenizer

    from forge.modeling.encoder import ForgeConfig, build_model
    from forge.training.data import WindowDataset

    cfg = load(config_path)
    mcfg = load(cfg["model_config"])
    tcfg = cfg["training"]
    exp = cfg.get("experiment", {})
    fpr_budget = float(cfg.get("fpr_budget", 0.001))

    out_dir = Path(cfg.get("output_dir", f"outputs/{exp.get('id', 'run')}"))
    if not out_dir.is_absolute():
        out_dir = REPO_ROOT / out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    backbone = mcfg["backbone"]
    max_len = int(mcfg.get("max_length", 512))
    stride = int(mcfg.get("window", {}).get("stride", 384))

    if smoke:
        # Fully offline: no downloads, no GPU. See forge.training.smoke for why.
        from forge.training.smoke import SmokeTokenizer

        backbone, max_len, stride = "smoke-tiny-encoder", 128, 96
        tcfg = {**tcfg, "epochs": int(os.getenv("FORGE_SMOKE_EPOCHS", "2")),
                "batch_size": 8, "grad_accum": 2, "precision": "fp32"}
        fpr_budget = 0.05
        tokenizer = SmokeTokenizer()
    else:
        tokenizer = AutoTokenizer.from_pretrained(backbone)

    print(f"[forge] device={device} backbone={backbone} max_len={max_len}")

    # ------------------------------------------------------------------ data
    if smoke:
        train_docs = _synthetic_docs(240, "train")
        val_docs = _synthetic_docs(120, "val")
    else:
        d = cfg["data"]
        train_docs = load_documents(d.get("human_root"), d.get("mirror_root"), ("train",))
        val_docs = load_documents(d.get("human_root"), d.get("mirror_root"), ("val",))
    if not train_docs or not val_docs:
        raise RuntimeError(
            "no documents loaded. Check data.human_root and data.mirror_root in the "
            "config, and that `forge ingest` and `forge mirror` have run."
        )

    train_ex = build_examples(train_docs, tokenizer, max_len, stride)
    val_ex = build_examples(val_docs, tokenizer, max_len, stride)
    assert_no_leakage(train_ex, val_ex)
    print(f"[forge] train windows={len(train_ex)}  val windows={len(val_ex)}  "
          f"train docs={len(train_docs)}  val docs={len(val_docs)}")

    pad_id = getattr(tokenizer, "pad_token_id", 0) or 0
    train_loader = DataLoader(
        WindowDataset(train_ex), batch_size=int(tcfg["batch_size"]), shuffle=True,
        collate_fn=lambda b: collate(b, pad_id), num_workers=2, drop_last=True,
    )
    val_loader = DataLoader(
        WindowDataset(val_ex), batch_size=int(tcfg["batch_size"]) * 2, shuffle=False,
        collate_fn=lambda b: collate(b, pad_id), num_workers=2,
    )

    # ----------------------------------------------------------------- model
    if smoke:
        from forge.training.smoke import build_smoke_model

        model = build_smoke_model().to(device)
    else:
        model = build_model(
            ForgeConfig(
                backbone=backbone, max_length=max_len, stride=stride,
                token_loss_weight=float(mcfg.get("token_loss_weight", 0.5)),
            )
        ).to(device)

    accum = int(tcfg.get("grad_accum", 1))
    epochs = int(tcfg["epochs"])
    steps_per_epoch = max(len(train_loader) // accum, 1)
    total_steps = steps_per_epoch * epochs

    optimizer = torch.optim.AdamW(
        model.parameters(), lr=float(tcfg["learning_rate"]),
        weight_decay=float(tcfg.get("weight_decay", 0.01)),
    )
    warmup = max(int(total_steps * float(tcfg.get("warmup_ratio", 0.06))), 1)

    def _lr_lambda(step: int) -> float:
        if step < warmup:
            return step / warmup
        return max(0.0, (total_steps - step) / max(total_steps - warmup, 1))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, _lr_lambda)
    precision = tcfg.get("precision", "bf16")
    use_amp = device == "cuda" and precision in ("bf16", "fp16")
    amp_dtype = torch.bfloat16 if precision == "bf16" else torch.float16
    scaler = torch.amp.GradScaler("cuda", enabled=(use_amp and precision == "fp16"))

    state = TrainState(dataset_version=str(cfg.get("data", {}).get("dataset_version", "")),
                       code_commit=_code_commit())
    if resume:
        state = load_checkpoint(resume, model, optimizer, scheduler, scaler)
        print(f"[forge] resumed from {resume} at epoch {state.epoch} step {state.global_step}")

    wandb_run = _maybe_wandb(exp, cfg)

    # ------------------------------------------------------------------ loop
    torch.manual_seed(int(tcfg.get("seed", 42)))
    for epoch in range(state.epoch, epochs):
        model.train()
        t0, running = time.time(), 0.0
        optimizer.zero_grad(set_to_none=True)
        for i, batch in enumerate(train_loader):
            with torch.autocast(device_type="cuda", dtype=amp_dtype, enabled=use_amp):
                out = model(
                    input_ids=batch["input_ids"].to(device),
                    attention_mask=batch["attention_mask"].to(device),
                    doc_labels=batch["doc_labels"].to(device),
                    token_labels=batch["token_labels"].to(device),
                )
                loss = out["loss"] / accum
            if scaler.is_enabled():
                scaler.scale(loss).backward()
            else:
                loss.backward()
            running += loss.detach().item() * accum

            if (i + 1) % accum == 0:
                if scaler.is_enabled():
                    scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                if scaler.is_enabled():
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    optimizer.step()
                scheduler.step()
                optimizer.zero_grad(set_to_none=True)
                state.global_step += 1
                if state.global_step % 50 == 0:
                    ex_s = (i + 1) * int(tcfg["batch_size"]) / (time.time() - t0)
                    print(f"  epoch {epoch} step {state.global_step}/{total_steps} "
                          f"loss {running / (i + 1):.4f}  {ex_s:.0f} ex/s")

        val = evaluate(model, val_loader, device, fpr_budget)
        val["epoch"] = epoch
        val["train_loss"] = running / max(len(train_loader), 1)
        val["epoch_seconds"] = round(time.time() - t0, 1)
        state.history.append(val)
        state.epoch = epoch + 1
        print(f"[forge] epoch {epoch}: FPR@{fpr_budget}={val['fpr']:.5f} "
              f"FNR={val['fnr']:.4f} AUROC={val['auroc']:.4f} ECE={val['ece']:.4f}")
        if wandb_run:
            wandb_run.log(val, step=state.global_step)

        save_checkpoint(out_dir / "last.pt", model, optimizer, scheduler, scaler, state)
        # Selection on FPR at budget, NOT on validation loss. See the module docstring.
        if val["fpr"] < state.best_fpr:
            state.best_fpr, state.best_epoch = val["fpr"], epoch
            save_checkpoint(out_dir / "best.pt", model, optimizer, scheduler, scaler, state)
            print(f"[forge] new best FPR {val['fpr']:.5f} at epoch {epoch}")

    report = {
        "experiment": exp,
        "backbone": backbone,
        "dataset_version": state.dataset_version,
        "code_commit": state.code_commit,
        "fpr_budget": fpr_budget,
        "best_epoch": state.best_epoch,
        "selected_on": "fpr_at_budget",
        "history": state.history,
        "final": state.history[-1] if state.history else {},
        "n_train_windows": len(train_ex),
        "n_val_windows": len(val_ex),
        "smoke": smoke,
    }
    p = out_dir / "eval_report.json"
    p.write_text(json.dumps(report, indent=2) + "\n")
    print(f"[forge] wrote {p}")
    if wandb_run:
        wandb_run.finish()
    return report


def _maybe_wandb(exp: dict, cfg: dict):
    if not os.getenv("WANDB_API_KEY"):
        return None
    try:
        import wandb

        return wandb.init(project=cfg.get("tracking", {}).get("project", "forge"),
                          name=exp.get("id"), config=cfg)
    except Exception as e:  # pragma: no cover
        print(f"[forge] wandb disabled: {e}")
        return None


def _synthetic_docs(n: int, split: str) -> list[dict]:
    """Tiny corpus for --smoke. Two distinguishable registers, so the loop should reach
    a non-trivial AUROC in one epoch. NOT training data."""
    import random

    rng = random.Random(0 if split == "train" else 1)
    human = ("The harbour authority published its annual dredging schedule in {m}, listing "
             "{n} operations across the estuary and the two tidal basins, and noted that "
             "silt had risen since the previous survey.")
    ai = ("It is important to note that dredging schedules serve several key purposes. "
          "First, they ensure navigability. Second, they support the local economy. "
          "In conclusion, careful planning in {m} with {n} operations remains essential.")
    months = ["March", "April", "May", "June", "July"]
    out = []
    for i in range(n):
        lab = i % 2
        tpl = ai if lab else human
        text = (tpl.format(m=rng.choice(months), n=rng.randint(3, 40)) + " ") * 4
        out.append({"doc_id": f"{split}_{i}", "source_group_id": f"grp_{split}_{i}",
                    "text": text, "split": split, "label": lab})
    return out
