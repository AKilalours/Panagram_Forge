"""Token-level metrics. Plan section 22.

Three metrics, measuring three genuinely different things, which is why reporting only
the first is misleading:

**Token F1** treats every token independently. A document that is 95 percent human scores
well on token F1 by predicting "human" everywhere, having found nothing. It is the
easiest metric and the least informative.

**Segment F1** asks whether the model found the right CONTIGUOUS RUNS. A prediction that
flickers human/AI/human/AI across a genuinely AI paragraph can have good token F1 and
terrible segment F1, and flickering is exactly what an unsmoothed token head does. This
is the metric that would actually settle the open smoothing question.

**Boundary F1** asks whether the model found the right TRANSITION POINTS, within a
tolerance. It is the hardest and the one that matters for the product: telling a user
"this document is 30 percent AI" is much less useful than showing them where.

Predicted and true labels are sequences of label ids, IGNORE_INDEX for positions that
carry no text.
"""

from __future__ import annotations

from dataclasses import dataclass

from forge.common.schemas import TokenLabel
from forge.modeling.alignment import IGNORE_INDEX, LABEL_TO_ID

HUMAN_ID = LABEL_TO_ID[TokenLabel.HUMAN]


def _f1(tp: int, fp: int, fn: int) -> float:
    if tp == 0:
        return 0.0
    p, r = tp / (tp + fp), tp / (tp + fn)
    return 2 * p * r / (p + r) if (p + r) else 0.0


def _valid(true: list[int], pred: list[int]) -> list[tuple[int, int]]:
    if len(true) != len(pred):
        raise ValueError("true and pred must be the same length")
    return [(t, p) for t, p in zip(true, pred) if t != IGNORE_INDEX]


def token_f1(true: list[int], pred: list[int], positive_is_ai: bool = True) -> float:
    """Binary F1 over tokens, positive class = any non-human label."""
    pairs = _valid(true, pred)
    tp = sum(1 for t, p in pairs if t != HUMAN_ID and p != HUMAN_ID)
    fp = sum(1 for t, p in pairs if t == HUMAN_ID and p != HUMAN_ID)
    fn = sum(1 for t, p in pairs if t != HUMAN_ID and p == HUMAN_ID)
    return _f1(tp, fp, fn)


def token_accuracy(true: list[int], pred: list[int]) -> float:
    pairs = _valid(true, pred)
    return sum(1 for t, p in pairs if t == p) / len(pairs) if pairs else 0.0


def segments(labels: list[int], skip_human: bool = True) -> list[tuple[int, int, int]]:
    """Contiguous runs as (start, end_exclusive, label), ignoring IGNORE_INDEX positions."""
    out: list[tuple[int, int, int]] = []
    start, cur = None, None
    for i, lab in enumerate(labels):
        if lab == IGNORE_INDEX:
            continue
        if lab != cur:
            if cur is not None and not (skip_human and cur == HUMAN_ID):
                out.append((start, i, cur))
            start, cur = i, lab
    if cur is not None and not (skip_human and cur == HUMAN_ID):
        out.append((start, len(labels), cur))
    return out


def segment_f1(true: list[int], pred: list[int], iou_threshold: float = 0.5) -> float:
    """F1 over non-human segments, matched by intersection-over-union.

    A predicted segment counts as correct when it overlaps a true segment of the same
    label by at least `iou_threshold`. Each true segment can be matched once, so a
    prediction that shatters one true span into six fragments is penalised, which is the
    whole point: token F1 would not notice.
    """
    t_segs, p_segs = segments(true), segments(pred)
    if not t_segs and not p_segs:
        return 1.0
    used, tp = set(), 0
    for ps, pe, pl in p_segs:
        best_i, best_iou = None, 0.0
        for i, (ts, te, tl) in enumerate(t_segs):
            if i in used or tl != pl:
                continue
            inter = max(0, min(pe, te) - max(ps, ts))
            union = max(pe, te) - min(ps, ts)
            iou = inter / union if union else 0.0
            if iou > best_iou:
                best_i, best_iou = i, iou
        if best_i is not None and best_iou >= iou_threshold:
            used.add(best_i)
            tp += 1
    return _f1(tp, len(p_segs) - tp, len(t_segs) - tp)


def boundaries(labels: list[int]) -> list[int]:
    """Indices where the label changes. The transitions, not the spans."""
    out, prev = [], None
    for i, lab in enumerate(labels):
        if lab == IGNORE_INDEX:
            continue
        if prev is not None and lab != prev:
            out.append(i)
        prev = lab
    return out


def boundary_f1(true: list[int], pred: list[int], tolerance: int = 5) -> float:
    """F1 over transition points, within +/- tolerance tokens.

    Tolerance exists because exact-token boundary agreement is not a meaningful target:
    tokenisers split words differently and a boundary off by two subword tokens is the
    same boundary to a reader. Report the tolerance alongside the number, since the metric
    is meaningless without it.
    """
    t_b, p_b = boundaries(true), boundaries(pred)
    if not t_b and not p_b:
        return 1.0
    used, tp = set(), 0
    for p in p_b:
        match = None
        for i, t in enumerate(t_b):
            if i in used:
                continue
            if abs(p - t) <= tolerance:
                match = i
                break
        if match is not None:
            used.add(match)
            tp += 1
    return _f1(tp, len(p_b) - tp, len(t_b) - tp)


@dataclass
class TokenScores:
    token_f1: float
    token_accuracy: float
    segment_f1: float
    boundary_f1: float
    boundary_tolerance: int
    n_true_segments: int
    n_pred_segments: int

    def as_dict(self) -> dict:
        return {
            "token_f1": round(self.token_f1, 6),
            "token_accuracy": round(self.token_accuracy, 6),
            "segment_f1": round(self.segment_f1, 6),
            "boundary_f1": round(self.boundary_f1, 6),
            "boundary_tolerance_tokens": self.boundary_tolerance,
            "n_true_segments": self.n_true_segments,
            "n_pred_segments": self.n_pred_segments,
        }


def score(true: list[int], pred: list[int], tolerance: int = 5, iou: float = 0.5) -> TokenScores:
    return TokenScores(
        token_f1=token_f1(true, pred),
        token_accuracy=token_accuracy(true, pred),
        segment_f1=segment_f1(true, pred, iou),
        boundary_f1=boundary_f1(true, pred, tolerance),
        boundary_tolerance=tolerance,
        n_true_segments=len(segments(true)),
        n_pred_segments=len(segments(pred)),
    )
